﻿using System.ComponentModel.DataAnnotations;
namespace AdministracionAguaPotable.Models
{
    public class Login
    {
        [Key]
        public int IdLogin { get; set; }
        public string Usuario { get; set; }
        public string Clave { get; set; }
        public string TipoUsuario { get; set; }
    }

}
