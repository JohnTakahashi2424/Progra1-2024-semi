﻿using System.ComponentModel.DataAnnotations;
namespace AdministracionAguaPotable.Models
{
    public class Cobro
    {
        [Key]
        public int IdCobro { get; set; }
        public int IdFactura { get; set; }
        public string MetodoPago { get; set; }
        public DateTime FechaPago { get; set; }
        public decimal MontoPagado { get; set; }

        public Factura Factura { get; set; }
    }

}
