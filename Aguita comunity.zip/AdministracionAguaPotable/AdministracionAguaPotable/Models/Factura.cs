﻿using System.ComponentModel.DataAnnotations;
namespace AdministracionAguaPotable.Models
{
    public class Factura
    {
        [Key]
        public int IdFactura { get; set; }
        public int IdUsuario { get; set; }
        public DateTime FechaEmision { get; set; }
        public DateTime FechaVencimiento { get; set; }
        public decimal TotalConsumo { get; set; }
        public string TipoDeuda { get; set; }
        public string Estado { get; set; }

        public Usuario Usuario { get; set; }
    }

}
