﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace AdministracionAguaPotable.Models
{
    public class Usuario
    {
        [Key]
        public int IdUsuario { get; set; }
        public int NumeroContador { get; set; }
        public string Nombre { get; set; }
        public string DUI { get; set; }
        public string Direccion { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public char Estado { get; set; }

        public ICollection<Factura> Facturas { get; set; }

        public ICollection<Lectura> Lecturas { get; set; }
    }

}
