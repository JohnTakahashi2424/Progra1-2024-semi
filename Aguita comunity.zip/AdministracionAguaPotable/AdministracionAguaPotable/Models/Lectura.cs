﻿using System.ComponentModel.DataAnnotations;
namespace AdministracionAguaPotable.Models
{
    public class Lectura
    {
        [Key]
        public int IdLectura { get; set; }
        public int IdUsuario { get; set; }
        public DateTime FechaLectura { get; set; }
        public decimal ConsumoM3 { get; set; }
        public decimal TotalCalculado { get; set; }

        public Usuario Usuario { get; set; }
    }

}
