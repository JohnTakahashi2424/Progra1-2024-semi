﻿using AdministracionAguaPotable.Data;
using AdministracionAguaPotable.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace AdministracionAguaPotable.Services
{
    public class AuthService
    {
        private readonly AppDbContext _context;

        public AuthService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<bool> Authenticate(string username, string password)
        {
            var user = await _context.Logins
                .Where(l => l.Usuario == username && l.Clave == password)
                .FirstOrDefaultAsync();

            return user != null;
        }
    }
}

