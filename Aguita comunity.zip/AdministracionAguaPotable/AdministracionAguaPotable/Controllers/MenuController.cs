﻿using Microsoft.AspNetCore.Mvc;
namespace AdministracionAguaPotable.Controllers
{
    public class MenuController : Controller
    {
        public IActionResult Menu()
        {
            return View(); 
        }
    }
}
