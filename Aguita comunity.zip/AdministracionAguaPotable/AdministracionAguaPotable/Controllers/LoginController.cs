﻿using Microsoft.AspNetCore.Mvc;
using AdministracionAguaPotable.Models;
using System.Threading.Tasks;
using AdministracionAguaPotable.Services;
namespace AdministracionAguaPotable.Controllers
{
    public class LoginController : Controller
    {
        private readonly AuthService _authService;

        public LoginController(AuthService authService)
        {
            _authService = authService;
        }

        [HttpPost]
        public async Task<IActionResult> Login(Login login)
        {
            if (await _authService.Authenticate(login.Usuario, login.Clave))
            {
                return RedirectToAction("Menu", "Menu");  // Redirige al controlador Menu si las credenciales son correctas
            }

            TempData["ErrorMessage"] = "Usuario o contraseña incorrectos";  // Muestra mensaje de error si las credenciales son incorrectas
            return RedirectToAction("Login");  // Vuelve al formulario de login si las credenciales son incorrectas
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();  // Muestra la vista del login
        }
    }
}
