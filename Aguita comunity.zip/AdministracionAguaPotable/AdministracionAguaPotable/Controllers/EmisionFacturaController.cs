﻿using Microsoft.AspNetCore.Mvc;
using AdministracionAguaPotable.Data;
using AdministracionAguaPotable.Models;
using Microsoft.EntityFrameworkCore;

namespace AdministracionAguaPotable.Controllers
{
    public class EmisionFacturaController : Controller
    {
        private readonly AppDbContext _context;

        public EmisionFacturaController(AppDbContext context)
        {
            _context = context;
        }

        // Vista inicial para mostrar las facturas no emitidas
        public async Task<IActionResult> Index()
        {
            var facturasNoEmitidas = await _context.Facturas
                .Where(f => f.Estado != "Emitida") // Filtrar solo las facturas no emitidas
                .Include(f => f.Usuario) // Incluir Usuario para mostrar sus detalles
                .ToListAsync();

            return View(facturasNoEmitidas);
        }

        // Vista de la factura seleccionada para vista previa
        public async Task<IActionResult> VistaPrevia(int id)
        {
            var factura = await _context.Facturas
                .Include(f => f.Usuario)
                .FirstOrDefaultAsync(f => f.IdFactura == id);

            if (factura == null)
            {
                return NotFound();
            }

            return View(factura);
        }

        // Acción para emitir la factura
        [HttpPost]
        public async Task<IActionResult> EmitirFactura(int id)
        {
            var factura = await _context.Facturas
                .FirstOrDefaultAsync(f => f.IdFactura == id);

            if (factura == null)
            {
                return NotFound();
            }

            // Marcar la factura como emitida
            factura.Estado = "Emitida";
            await _context.SaveChangesAsync();

            // Redirigir a la vista de facturas emitidas
            return RedirectToAction(nameof(Index));
        }
    }
}


