﻿using Microsoft.AspNetCore.Mvc;
using AdministracionAguaPotable.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using AdministracionAguaPotable.Data;

namespace AdministracionAguaPotable.Controllers
{
    public class FacturaController : Controller
    {
        private readonly AppDbContext _context;

        public FacturaController(AppDbContext context)
        {
            _context = context;
        }

        // Vista para listar las facturas
        public async Task<IActionResult> Index()
        {
            var facturas = await _context.Facturas.Include(f => f.Usuario).ToListAsync();
            return View(facturas);
        }

        // Acción para buscar facturas
        [HttpGet]
        public async Task<IActionResult> Buscar(string query)
        {
            // Si no hay un término de búsqueda, redirigir al Index
            if (string.IsNullOrWhiteSpace(query))
            {
                return RedirectToAction(nameof(Index));
            }

            // Filtrar facturas por el término de búsqueda
            var facturas = await _context.Facturas
                .Include(f => f.Usuario)
                .Where(f => f.TipoDeuda.Contains(query) ||
                            f.Estado.Contains(query) ||
                            f.Usuario.Nombre.Contains(query))
                .ToListAsync();

            // Mostrar los resultados en la vista Index
            return View(nameof(Index), facturas);
        }

        // Vista para agregar una nueva factura
        public IActionResult Crear()
        {
            ViewData["Usuarios"] = _context.Usuarios.Where(u => u.Estado == 'A').ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Crear(Factura factura)
        {
            if (ModelState.IsValid)
            {
                _context.Add(factura);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewData["Usuarios"] = _context.Usuarios.Where(u => u.Estado == 'A').ToList();
            return View(factura);
        }

        public async Task<IActionResult> Editar(int id)
        {
            var factura = await _context.Facturas.FindAsync(id);
            if (factura == null)
            {
                return NotFound();
            }

            ViewData["Usuarios"] = _context.Usuarios.Where(u => u.Estado == 'A').ToList();
            return View(factura);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Editar(int id, Factura factura)
        {
            if (id != factura.IdFactura)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(factura);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FacturaExists(factura.IdFactura))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["Usuarios"] = _context.Usuarios.Where(u => u.Estado == 'A').ToList();
            return View(factura);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Eliminar(int id)
        {
            var factura = await _context.Facturas.FindAsync(id);
            if (factura == null)
            {
                return NotFound();
            }
            _context.Facturas.Remove(factura);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FacturaExists(int id)
        {
            return _context.Facturas.Any(e => e.IdFactura == id);
        }
    }
}


