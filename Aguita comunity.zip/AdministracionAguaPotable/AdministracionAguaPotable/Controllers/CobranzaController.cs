﻿using Microsoft.AspNetCore.Mvc;
using AdministracionAguaPotable.Models;
using AdministracionAguaPotable.Data;
using Microsoft.EntityFrameworkCore;

namespace AdministracionAguaPotable.Controllers
{
    public class CobranzaController : Controller
    {
        private readonly AppDbContext _context;

        public CobranzaController(AppDbContext context)
        {
            _context = context;
        }

        // Mostrar facturas pendientes para un usuario
        public async Task<IActionResult> Index(int usuarioId)
        {
            var facturasPendientes = await _context.Facturas
                .Include(f => f.Usuario)
                .Where(f => f.IdUsuario == usuarioId && f.Estado != "Pagada")
                .ToListAsync();

            return View(facturasPendientes);
        }

        // Registrar el cobro
        [HttpPost]
        public async Task<IActionResult> Pagar(int[] facturaIds, decimal montoPagado, string metodoPago)
        {
            foreach (var facturaId in facturaIds)
            {
                var factura = await _context.Facturas.FindAsync(facturaId);

                if (factura != null)
                {
                    var cobro = new Cobro
                    {
                        IdFactura = factura.IdFactura,
                        MontoPagado = montoPagado,
                        FechaPago = DateTime.Now,
                        MetodoPago = metodoPago,
                        Factura = factura
                    };

                    // Actualizar el estado de la factura a "Pagada"
                    factura.Estado = "Pagada";

                    _context.Cobros.Add(cobro);
                    await _context.SaveChangesAsync();
                }
            }

            return RedirectToAction("Comprobante", new { facturaIds = string.Join(",", facturaIds) });
        }

        // Vista de comprobante de pago
        public async Task<IActionResult> Comprobante(string facturaIds)
        {
            var ids = facturaIds.Split(',').Select(int.Parse).ToList();
            var facturas = await _context.Facturas
                .Where(f => ids.Contains(f.IdFactura))
                .Include(f => f.Usuario)
                .ToListAsync();

            return View(facturas);
        }
    }
}

