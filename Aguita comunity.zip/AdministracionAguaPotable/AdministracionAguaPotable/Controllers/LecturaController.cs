﻿using Microsoft.AspNetCore.Mvc;
using AdministracionAguaPotable.Models;
using AdministracionAguaPotable.Data;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace AdministracionAguaPotable.Controllers
{
    public class LecturaController : Controller
    {
        private readonly AppDbContext _context;

        public LecturaController(AppDbContext context)
        {
            _context = context;
        }

        // GET: Lectura/Create
        public IActionResult Create()
        {
            ViewBag.FacturasPendientes = _context.Facturas.Where(f => f.Estado == "Pendiente").ToList();
            return View();
        }

        // POST: Lectura/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Lectura lectura)
        {
            if (ModelState.IsValid)
            {
                // Cálculo del Total a Pagar (por ejemplo, un monto fijo por metro cúbico)
                var factura = _context.Facturas.Find(lectura.IdUsuario);
                if (factura != null)
                {
                    lectura.TotalCalculado = lectura.ConsumoM3 * 5.00M; // Precio fijo por m3 (puedes ajustarlo)
                    factura.Estado = "Pagada"; // Cambiar el estado de la factura a "Pagada"
                    _context.Update(factura);
                }
                _context.Add(lectura);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index"); // Redirigir a la lista de lecturas
            }
            return View(lectura);
        }

        // GET: Lectura/Index
        public IActionResult Index()
        {
            var lecturas = _context.Lecturas.Include(l => l.Usuario).ToList();
            return View(lecturas);
        }
    }
}

