﻿namespace AdministracionAguaPotable.Data;
using Microsoft.EntityFrameworkCore;
using AdministracionAguaPotable.Models;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Usuario> Usuarios { get; set; }
    public DbSet<Factura> Facturas { get; set; }
    public DbSet<Lectura> Lecturas { get; set; }
    public DbSet<Cobro> Cobros { get; set; }
    public DbSet<Login> Logins { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Factura>()
            .HasOne(f => f.Usuario)
            .WithMany(u => u.Facturas)
            .HasForeignKey(f => f.IdUsuario)
            .OnDelete(DeleteBehavior.Restrict); 

        modelBuilder.Entity<Lectura>()
            .HasOne(l => l.Usuario)
            .WithMany(u => u.Lecturas)
            .HasForeignKey(l => l.IdUsuario)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Cobro>()
            .HasOne(c => c.Factura)
            .WithOne()
            .HasForeignKey<Cobro>(c => c.IdFactura)
            .OnDelete(DeleteBehavior.Restrict); 
    }
}
